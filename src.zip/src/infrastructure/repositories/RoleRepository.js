// infrastructure/repositories/RoleRepository.js
const RoleModel = require("../db/RoleModel");
const Role = require("../../domain/entities/Role");

class RoleRepository {
  _toEntity(doc) {
    if (!doc) return null;
    const obj = doc.toObject ? doc.toObject() : doc;
    return new Role({ ...obj, id: obj._id.toString() });
  }

  async findAll(filters = {}) {
    const query = {};
    if (filters.search) {
      const re = new RegExp(filters.search, "i");
      query.$or = [{ nombre: re }, { descripcion: re }];
    }
    if (filters.estado !== undefined) {
      query.estado = filters.estado === "true" || filters.estado === true;
    }
    const docs = await RoleModel.find(query);
    return docs.map((d) => this._toEntity(d));
  }

  async findById(id) {
    const doc = await RoleModel.findById(id).catch(() => null);
    return this._toEntity(doc);
  }

  async findByName(nombre) {
    const doc = await RoleModel.findOne({ nombre });
    return this._toEntity(doc);
  }

  async create(data) {
    const doc = await RoleModel.create(data);
    return this._toEntity(doc);
  }

  async update(id, changes) {
    const doc = await RoleModel.findByIdAndUpdate(id, changes, { new: true }).catch(() => null);
    return this._toEntity(doc);
  }

  async delete(id) {
    const result = await RoleModel.findByIdAndDelete(id).catch(() => null);
    return !!result;
  }
}

module.exports = RoleRepository;
