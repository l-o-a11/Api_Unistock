// ─────────────────────────────────────────────────────────────────────────────
// src/infrastructure/controllers/productionController.js
// ─────────────────────────────────────────────────────────────────────────────

const mongoose = require("mongoose");

const ProductionRepository            = require("../repositories/ProductionRepository");
const ProductionOrderDetailRepository = require("../repositories/ProductionOrderDetailRepository");
const ThirdPartyAssignmentRepository  = require("../repositories/ThirdPartyAssignmentRepository");
const ProductRepository               = require("../repositories/ProductRepository");
const TechnicalSheetRepository        = require("../repositories/TechnicalSpecificationsRepository");
// ✅ Carga laboral de empleados (asignación de responsable en Corte/Compras/Recepción).
// UserModel aquí es el modelo "mínimo" de solo lectura — el CRUD real vive en Api_Unistock,
// pero ambos backends apuntan a la misma base de datos "unistock".
const UserModel          = require("../db/UserModel");
const ProductionOrderModel = require("../db/ProductionOrderModel");

const AnularProduction       = require("../../application/use-cases/production/AnularProduction");
const CambiarEstadoProduction = require("../../application/use-cases/production/CambiarEstadoProduction");
const CreateOrderDetail      = require("../../application/use-cases/production/CreateOrderDetail");
const GetOrderDetails        = require("../../application/use-cases/production/GetOrderDetails");

const Production = require("../../domain/entities/Production");
const GetCalendarioProduction = require("../../application/use-cases/production/GetCalendarioProduction");
const GetAlertasProduction    = require("../../application/use-cases/production/GetAlertasProduction");
const GetProductions          = require("../../application/use-cases/production/GetProductions");
const AsignarEmpleadoProduccion  = require("../../application/use-cases/production/AsignarEmpleadoProduccion");
const ReasignarEmpleadoProduccion = require("../../application/use-cases/production/ReasignarEmpleadoProduccion");
const ConfirmarEtapaProduccion   = require("../../application/use-cases/production/ConfirmarEtapaProduccion");
const UserRepository             = require("../repositories/UserRepository");
const ClientRepository            = require("../repositories/ClientRepository");
const SiteRepository              = require("../repositories/SiteRepository");

const { ok, created, badRequest, notFound, serverError } = require("../../shared/utils/response");

const prodRepo       = new ProductionRepository();
const detailRepo     = new ProductionOrderDetailRepository();
const assignmentRepo = new ThirdPartyAssignmentRepository();
const productRepo    = new ProductRepository();
const techSheetRepo  = new TechnicalSheetRepository();

// ── Helpers ───────────────────────────────────────────────────────────────────

/**
 * Devuelve serverError con el mensaje real en desarrollo,
 * y genérico en producción.
 */
const handleError = (res, err) => {
  console.error("[ProductionController]", err);
  const msg = process.env.NODE_ENV !== "production" ? err.message : undefined;
  return serverError(res, msg);
};

const resolveUserName = async (req, userId) => {
  if (!userId) return "Sistema";
  if (req.user?.nombreCompleto) return req.user.nombreCompleto;
  if (req.user?.nombre) return req.user.nombre;
  if (req.user?.username) return req.user.username;
  try {
    const user = await new UserRepository().findById(userId);
    const name = user?.nombreCompleto || user?.nombre || user?.username || String(userId);
    req.user = req.user || {};
    req.user.nombreCompleto = name;
    return name;
  } catch {
    return String(userId);
  }
};

/**
 * Al pasar una orden a "Enviado", se suman las cantidades de cada detalle
 * (agrupadas por id_producto) al stock del producto correspondiente
 * (los detalles guardan id_producto = referencia del producto, no el _id).
 */
const aplicarIngresoStockPorEnvio = async (idOrden) => {
  try {
    const detalles = await detailRepo.findAll({ id_orden: idOrden });
    if (!detalles?.length) return;

    // Agrupar cantidades por referencia de producto (puede haber varios colores)
    const cantidadPorReferencia = new Map();
    for (const d of detalles) {
      const ref = d.id_producto;
      if (!ref) continue;
      cantidadPorReferencia.set(ref, (cantidadPorReferencia.get(ref) || 0) + Number(d.cantidad || 0));
    }

    for (const [referencia, cantidad] of cantidadPorReferencia.entries()) {
      if (!cantidad) continue;
      const product = await productRepo.findByReference(referencia).catch(() => null);
      if (!product) {
        console.warn(`[ProductionController] No se encontró producto con referencia "${referencia}" para sumar stock`);
        continue;
      }
      // Suma atómica: toma el stock que el producto tenga en ese momento y le agrega la cantidad enviada
      await productRepo.incrementStock(product.id, cantidad);
    }
  } catch (err) {
    console.error("[ProductionController] Error al actualizar stock por envío:", err);
  }
};

// ── Órdenes ───────────────────────────────────────────────────────────────────

const getOrders = async (req, res) => {
  try {
    const result = await prodRepo.findAll(req.query);
    const orders = Array.isArray(result?.data) ? result.data : [];
    const mappedOrders = orders.map((o) => o.toJSON?.() || o);
    return ok(res, {
      data: mappedOrders,
      total: result.total || 0,
      page: result.page || 1,
      limit: result.limit || mappedOrders.length,
      totalPages: result.totalPages || 0,
    });
  } catch (err) {
    return handleError(res, err);
  }
};

const getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return badRequest(res, `ID de orden inválido: "${id}"`);
    }
    const order = await prodRepo.findById(id);
    if (!order) {
      console.warn(`[ProductionController] getOrderById 404 id=${id}`);
      return notFound(res, "Orden no encontrada");
    }
    const details = await detailRepo.findAll({ id_orden: id });
    return ok(res, { ...order.toJSON(), detalles: details.map((d) => d.toJSON()) });
  } catch (err) {
    return handleError(res, err);
  }
};

const createOrder = async (req, res) => {
  try {
    const data = req.validatedData || req.body;
    const { fecha_entrega, cliente, id_usuario } = data;
    const userId = id_usuario || req.user?.id || "anonymous";

    if (!fecha_entrega || !cliente)
      return badRequest(res, "Los campos fecha_entrega y cliente son requeridos");

    const tipo = data.tipo || data.type || "produccion";
    const referencia = data.referencia || data.reference || null;
    const producto = data.producto || data.product || null;
    const designImages = Array.isArray(data.designImages) ? data.designImages : [];
    const finishedImages = Array.isArray(data.finishedImages) ? data.finishedImages : [];
    const finishedImageUrl = typeof data.finishedImageUrl === 'string' ? data.finishedImageUrl : null;

    const normalizeImageArray = (arr) => {
      if (!Array.isArray(arr)) return [];
      return arr
        .map((item) => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') return item.url || item.src || item.secure_url || null;
          return null;
        })
        .filter(Boolean);
    };

    const normalizedDesignImages = normalizeImageArray(designImages);
    const normalizedFinishedImages = normalizeImageArray(finishedImages);
    const normalizedFinishedImageUrl = (typeof finishedImageUrl === 'string' && finishedImageUrl.trim()) || null;

    console.log('[ProductionController] createOrder imagenes:', {
      designImages: normalizedDesignImages,
      finishedImages: normalizedFinishedImages,
      finishedImageUrl: normalizedFinishedImageUrl,
    });
    const fromDamaged = data.fromDamaged === true || data.fromDamaged === "true";
    const originalOrderNumber = data.originalOrderNumber || data.original_order_number || null;
    const originalOrderStatus = data.originalOrderStatus || data.original_order_status || null;

    let techSpecification = data.techSpecification || data.techSheet || null;
    const isProduccion = tipo === "produccion";

    if (isProduccion && referencia) {
      let product = null;
      const refTrimmed = String(referencia).trim();
      if (mongoose.isValidObjectId(refTrimmed)) {
        product = await productRepo.findById(refTrimmed).catch(() => null);
      }
      if (!product) product = await productRepo.findByReference(refTrimmed).catch(() => null);
      if (!product && refTrimmed !== referencia) {
        product = await productRepo.findByReference(referencia).catch(() => null);
      }
      if (product) {
        if (!techSpecification) {
          const specs = await techSheetRepo.findAll({ id_producto: product.id }).catch(() => []);
          const activeSpec = specs && specs.length ? specs[0] : null;
          if (activeSpec) techSpecification = activeSpec;
        }

        if (techSpecification && Number(product.precio) > 0) {
          techSpecification = {
            ...techSpecification,
            costPerUnit: Number(product.precio),
          };
        }
      }
    }

    const estadoInicial = isProduccion ? "Ficha Técnica" : "Diseño";

    const order = await prodRepo.create({
      fecha_entrega,
      cliente,
      id_usuario: userId,
      tipo,
      producto,
      referencia,
      techSpecification,
      designImages: normalizedDesignImages,
      finishedImages: normalizedFinishedImages,
      finishedImageUrl: normalizedFinishedImageUrl,
      fromDamaged,
      originalOrderNumber,
      originalOrderStatus,
      estado: estadoInicial,
      historial: [{ estado: "Diseño", fecha: new Date(), id_usuario: userId, motivo: null }],
    });
    return created(res, order.toJSON());
  } catch (err) {
    return handleError(res, err);
  }
};

const updateOrder = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return badRequest(res, `ID de orden inválido: "${id}"`);
    }
    const order = await prodRepo.findById(id);
    if (!order) return notFound(res, "Orden no encontrada");

    if (order.estaAnulada())
      return badRequest(res, "No se puede editar una orden anulada");

    const { estado, historial, motivo_anulacion, ...rest } = req.body;

    const ALLOWED_FIELDS = new Set([
      "cliente",
      "fecha_entrega",
      "id_usuario",
      "asignaciones",
      "empleadoAsignaciones",
      "tipo",
      "referencia",
      "producto",
      "techSpecification",
      "designImages",
      "finishedImages",
      "finishedImageUrl",
      "fromDamaged",
      "originalOrderNumber",
      "originalOrderStatus",
    ]);

    const safeChanges = {};
    for (const [key, value] of Object.entries(rest)) {
      if (ALLOWED_FIELDS.has(key) && value !== undefined) {
        safeChanges[key] = value;
      }
    }

    if (Object.prototype.hasOwnProperty.call(safeChanges, "cliente")) {
      const cliente = typeof safeChanges.cliente === "string" ? safeChanges.cliente.trim() : safeChanges.cliente;
      if (!cliente) return badRequest(res, "El cliente no puede estar vacío");
      safeChanges.cliente = cliente;
    }

    if (Object.prototype.hasOwnProperty.call(safeChanges, "fecha_entrega")) {
      const fecha = new Date(safeChanges.fecha_entrega);
      if (!safeChanges.fecha_entrega || Number.isNaN(fecha.getTime())) {
        return badRequest(res, "La fecha de entrega no es válida");
      }
      safeChanges.fecha_entrega = fecha;
    }

    const normalizeImageArray = (arr) => {
      if (!Array.isArray(arr)) return [];
      return arr
        .map((item) => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') return item.url || item.src || item.secure_url || null;
          return null;
        })
        .filter(Boolean);
    };

    if (Object.prototype.hasOwnProperty.call(safeChanges, "designImages")) {
      safeChanges.designImages = normalizeImageArray(safeChanges.designImages);
    }
    if (Object.prototype.hasOwnProperty.call(safeChanges, "finishedImages")) {
      safeChanges.finishedImages = normalizeImageArray(safeChanges.finishedImages);
    }
    if (Object.prototype.hasOwnProperty.call(safeChanges, "finishedImageUrl")) {
      const url = safeChanges.finishedImageUrl;
      safeChanges.finishedImageUrl = (typeof url === 'string' && url.trim()) || null;
    }

    console.log('[ProductionController] updateOrder safeChanges:', JSON.stringify(safeChanges));

    const updated = await prodRepo.update(req.params.id, safeChanges);
    if (!updated) return serverError(res, "Error al actualizar la orden");
    return ok(res, updated.toJSON());
  } catch (err) {
    if (err.name === "ValidationError" || err.name === "CastError") {
      return badRequest(res, err.message);
    }
    return handleError(res, err);
  }
};

// ── Anular orden ──────────────────────────────────────────────────────────────

const anularOrder = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return badRequest(res, `ID de orden inválido: "${id}"`);
    }
    const { motivo, id_usuario: bodyUser, user: bodyUserName } = req.body;
    const id_usuario = bodyUser || req.user?.id || null;
    const user = await resolveUserName(req, id_usuario);

    const useCase = new AnularProduction(prodRepo);
    const result  = await useCase.execute(id, motivo, id_usuario, user);
    return ok(res, result);
  } catch (err) {
    if (err.statusCode === 404) {
      console.warn(`[ProductionController] anularOrder 404 id=${req.params.id} motivo=${err.message}`);
      return notFound(res, err.message);
    }
    if (err.statusCode === 400 || err.statusCode === 422) return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── Cambiar estado ────────────────────────────────────────────────────────────

const cambiarEstado = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.isValidObjectId(id)) {
      return badRequest(res, `ID de orden inválido: "${id}"`);
    }
    const { estado, id_usuario: bodyUser, user: bodyUserName, force, ...rest } = req.body;
    const id_usuario = bodyUser || req.user?.id || null;
    const user = await resolveUserName(req, id_usuario);
    console.log(`[ProductionController] cambiarEstado called id=${id} estado=${estado} id_usuario=${id_usuario} force=${!!force}`);
    console.log('[ProductionController] payload extra:', rest);

    const normalizeImageArray = (arr) => {
      if (!Array.isArray(arr)) return [];
      return arr
        .map((item) => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') return item.url || item.src || item.secure_url || null;
          return null;
        })
        .filter(Boolean);
    };

    if (rest.designImages !== undefined) rest.designImages = normalizeImageArray(rest.designImages);
    if (rest.finishedImages !== undefined) rest.finishedImages = normalizeImageArray(rest.finishedImages);
    if (rest.finishedImageUrl !== undefined) {
      const url = rest.finishedImageUrl;
      rest.finishedImageUrl = (typeof url === 'string' && url.trim()) || null;
    }

    // Si retrocedemos a un estado igual o anterior a "Compras", eliminamos las asignaciones de terceros de la orden
    const Production = require("../../domain/entities/Production");
    const targetIdx = Production.ESTADOS_VALIDOS.indexOf(estado);
    const comprasIdx = Production.ESTADOS_VALIDOS.indexOf("Compras");
    if (targetIdx !== -1 && targetIdx <= comprasIdx) {
      console.log(`[ProductionController] Retrocediendo al estado "${estado}". Eliminando asignaciones para orden ${req.params.id}`);
      await assignmentRepo.deleteByOrder(req.params.id);
    }

    const useCase = new CambiarEstadoProduction(
      prodRepo,
      new UserRepository(),
      new ClientRepository(),
      new SiteRepository(),
    );
    const result  = await useCase.execute(req.params.id, estado, id_usuario, user, {
      force: !!force, extra: rest,
      solicitante: req.user
        ? { id: req.user.id || req.user._id, rolNombre: req.user.rolNombre }
        : null,
    });

    let response = result;
    if (estado === "Corte") {
      await detailRepo.assignRefCorteForOrder(req.params.id);
      const details = await detailRepo.findAll({ id_orden: req.params.id });
      response = { ...result, detalles: details.map((detail) => detail.toJSON()) };
    }
      console.log('[ProductionController] cambiarEstado result:', result && result.id ? result.id : result);

    // Al confirmar el envío, los productos fabricados ingresan al stock
    if (estado === "Enviado") {
      await aplicarIngresoStockPorEnvio(req.params.id);
    }

    return ok(res, response);
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    if (err.statusCode === 400 || err.statusCode === 422) return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── Obtener estados válidos ───────────────────────────────────────────────────

const getEstados = (_req, res) => {
  return ok(res, Production.ESTADOS_VALIDOS);
};

// ── Detalles de orden ─────────────────────────────────────────────────────────

const getOrderDetails = async (req, res) => {
  try {
    const useCase = new GetOrderDetails(detailRepo);
    return ok(res, await useCase.execute(req.query));
  } catch (err) {
    return handleError(res, err);
  }
};

const createOrderDetail = async (req, res) => {
  try {
    // Parsear cantidad a número por si llega como string desde el form
    const payload = {
      ...req.body,
      cantidad: req.body.cantidad !== undefined ? Number(req.body.cantidad) : undefined,
    };

    const order = await prodRepo.findById(payload.id_orden);
    const productionIndex = Production.ESTADOS_VALIDOS.indexOf("Producción");
    if (order && Production.ESTADOS_VALIDOS.indexOf(order.estado) >= productionIndex) {
      return badRequest(res, "No se pueden agregar detalles cuando la orden está en Producción o una etapa posterior");
    }

    const useCase = new CreateOrderDetail(detailRepo, prodRepo);
    const detail  = await useCase.execute(payload);

    // ✅ Si la orden ya está en etapa "Corte", asignar refCorte automáticamente
    // al nuevo detalle — mismo mecanismo que al avanzar el estado a Corte.
    if (!detail.refCorte) {
      const order = await prodRepo.findById(payload.id_orden).catch(() => null);
      if (order && order.estado === 'Corte') {
        try {
          const siguiente = (await detailRepo.countRefCorteByProducto(payload.id_producto)) + 1;
          const refCorte  = `${payload.id_producto}-${siguiente}`;
          await detailRepo.update(detail.id, { refCorte });
          const updated = await detailRepo.findById(detail.id);
          return created(res, updated);
        } catch (e) {
          console.warn('No se pudo asignar refCorte automáticamente:', e?.message);
        }
      }
    }

    return created(res, detail);
  } catch (err) {
    if (err.statusCode === 400)  return badRequest(res, err.message);
    if (err.statusCode === 404)  return notFound(res, err.message);
    if (err.statusCode === 422)  return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── DELETE /produccion/detalle-orden/:id ──────────────────────────────────────
// Elimina un detalle de orden y registra la acción en el historial de la orden.
const deleteOrderDetail = async (req, res) => {
  try {
    const detail = await detailRepo.findById(req.params.id);
    if (!detail) return notFound(res, 'Detalle no encontrado');

    const order = await prodRepo.findById(detail.id_orden);
    const productionIndex = Production.ESTADOS_VALIDOS.indexOf("Producción");
    const isDamageAdjustment = req.body?.ajusteDanio === true;
    if (!isDamageAdjustment && order && Production.ESTADOS_VALIDOS.indexOf(order.estado) >= productionIndex) {
      return badRequest(res, "No se pueden eliminar detalles cuando la orden está en Producción o una etapa posterior");
    }

    const deleted = await detailRepo.delete(req.params.id);
    if (!deleted) return notFound(res, 'No se pudo eliminar el detalle');

// Registrar en el historial de la orden
    const userId   = req.user?.id || req.user?._id || null;
    const userName = req.user?.nombreCompleto || req.user?.nombre || req.user?.username || 'Sistema';
    await prodRepo.agregarHistorial(
      detail.id_orden,
      `Artículo ${detail.id_producto} (${detail.color || 'sin color'}, ${detail.cantidad} uds) eliminado`,
      userId,
      userName,
      'Referencia eliminada',
    ).catch(() => { /* no bloquear si el push falla */ });

    return ok(res, { deleted: true });
  } catch (err) {
    return handleError(res, err);
  }
};

const getAssignments = async (req, res) => {
  try {
    return ok(res, await assignmentRepo.findAll(req.query));
  } catch (err) {
    return handleError(res, err);
  }
};

const createAssignment = async (req, res) => {
  try {
    const { id_orden, id_tercero, cantidad } = req.body;
    if (!id_orden || !id_tercero || !cantidad)
      return badRequest(res, "Los campos id_orden, id_tercero y cantidad son requeridos");
    return created(res, await assignmentRepo.create({ id_orden, id_tercero, cantidad }));
  } catch (err) {
    return handleError(res, err);
  }
};


// ── Carga laboral de empleados (para asignar responsable en Corte/Compras/Recepción) ──

// Estados que ya no cuentan como "carga activa" para un empleado
const ESTADOS_FINALIZADOS = ["Enviado", "Anulada"];

/**
 * GET /produccion/empleados/carga
 * Devuelve los usuarios activos junto con la cantidad de órdenes de producción
 * activas (no Enviado/Anulada) en las que están asignados como responsables
 * de la etapa ACTUAL (empleadoAsignadoId), para poder repartir
 * la carga de trabajo al asignar un nuevo responsable.
 *
 * Cuenta desde `empleadoAsignaciones` (objeto que acumula
 * TODAS las asignaciones históricas del empleado por etapa), lo cual podía
 * inflar el conteo o mostrar 0 si el empleado solo estaba asignado en la
 * etapa actual. Ahora cuenta desde `empleadoAsignadoId` (el empleado
 * responsable de la etapa ACTUAL de la orden), que es el campo que realmente
 * refleja la carga de trabajo actual del empleado.
 */
const getEmployeeWorkload = async (req, res) => {
  try {
    const cargo = typeof req.query.cargo === "string" ? req.query.cargo.trim() : "";
    const sedeId = typeof req.query.sedeId === "string" ? req.query.sedeId.trim() : "";
    const normalizar = (value) => String(value || "")
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
    const cargoNormalizado = normalizar(cargo);

    const userQuery = { estado: true };
    if (sedeId && mongoose.isValidObjectId(sedeId)) {
      userQuery.sedeId = new mongoose.Types.ObjectId(sedeId);
    }

    // Usar la colección nativa evita que un documento legacy provoque un
    // CastError en el modelo Mongoose y tumbe todo el catálogo de empleados.
    const employees = await UserModel.collection
      .find(userQuery, {
        projection: { _id: 1, nombre: 1, nombreCompleto: 1, correo: 1, cargo: 1, sedeId: 1 },
      })
      .sort({ nombreCompleto: 1, nombre: 1 })
      .toArray();

    const disponibles = employees.filter((employee) => {
      const cargos = Array.isArray(employee.cargo) ? employee.cargo : [employee.cargo];
      return !cargoNormalizado || cargos.some((value) => normalizar(value) === cargoNormalizado);
    });

    // Cuenta desde `empleadoAsignadoId` (campo plano) en vez de
    // `empleadoAsignaciones` (objeto con todas las etapas históricas).
    // Así el conteo refleja la carga REAL del empleado en la etapa actual.
    let activeOrders = [];
    try {
      // Se consulta la colección nativa porque `empleadoAsignaciones` no
      // existe en el esquema actual, pero sí puede existir en documentos
      // legacy. Mongoose podría eliminar ese campo antes del conteo.
      activeOrders = await ProductionOrderModel.collection
        .find({ estado: { $nin: ESTADOS_FINALIZADOS } })
        .project({ estado: 1, empleadoAsignadoId: 1, empleadoAsignaciones: 1 })
        .toArray();
    } catch (err) {
      console.error("[Producción] No se pudo calcular la carga laboral:", err.message);
    }

    const countByEmployeeId = new Map();
    for (const order of activeOrders) {
      // Las órdenes nuevas guardan la carga en el campo plano. Las antiguas
      // pueden conservar la asignación por etapa en empleadoAsignaciones.
      const idEmpleado = order.empleadoAsignadoId ||
        order.empleadoAsignaciones?.[order.estado]?.id_empleado ||
        order.empleadoAsignaciones?.[order.estado]?.empleadoId ||
        order.empleadoAsignaciones?.[order.estado]?.idEmpleado;
      if (idEmpleado) {
        const key = String(idEmpleado);
        countByEmployeeId.set(key, (countByEmployeeId.get(key) || 0) + 1);
      }
    }

    const result = disponibles.map((u) => ({
      id: String(u._id),
      nombre: u.nombreCompleto || u.nombre,
      correo: u.correo,
      cargo: u.cargo,
      sedeId: u.sedeId ? String(u.sedeId) : null,
      produccionesAsignadas: countByEmployeeId.get(String(u._id)) || 0,
    }));

    return ok(res, result);
  } catch (err) {
    return handleError(res, err);
  }
};

// ── Calendario ────────────────────────────────────────────────────────────────

const getCalendario = async (req, res) => {
  try {
    const { desde, hasta } = req.query;
    const useCase = new GetCalendarioProduction(prodRepo);
    const result  = await useCase.execute(desde, hasta);
    return ok(res, result);
  } catch (err) {
    return handleError(res, err);
  }
};

// ── Alertas ───────────────────────────────────────────────────────────────────

const getAlertas = async (req, res) => {
  try {
    const useCase = new GetAlertasProduction(prodRepo);
    const result  = await useCase.execute();
    return ok(res, result);
  } catch (err) {
    return handleError(res, err);
  }
};

// ── Asignar empleado a etapa actual ──────────────────────────────────────────

const asignarEmpleado = async (req, res) => {
  try {
    const empleadoId = req.body.id_empleado || req.body.empleadoId;
    if (!empleadoId) return badRequest(res, "El campo id_empleado es requerido");

    const userRepo = new UserRepository();
    const useCase  = new AsignarEmpleadoProduccion(prodRepo, userRepo);
    const result   = await useCase.execute(req.params.id, empleadoId);
    return ok(res, result);
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    if (err.statusCode === 422 || err.statusCode === 403 || err.statusCode === 401) return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── Reasignar empleado a etapa actual (reemplazo con justificación) ─────────

const reasignarEmpleado = async (req, res) => {
  try {
    const empleadoId = req.body.id_empleado || req.body.empleadoId;
    const motivo = (req.body.motivo || "").toString().trim();
    if (!empleadoId) return badRequest(res, "El campo id_empleado es requerido");

    const solicitanteId = req.user?.id || req.user?._id || null;
    const solicitanteNombre = await resolveUserName(req, solicitanteId);

    const useCase = new ReasignarEmpleadoProduccion(prodRepo, new UserRepository());
    const result = await useCase.execute(req.params.id, empleadoId, motivo, solicitanteId, solicitanteNombre);

    return ok(res, result);
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    if (err.statusCode === 422 || err.statusCode === 403 || err.statusCode === 401) return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── Confirmar etapa por empleado ─────────────────────────────────────────────

const confirmarEtapa = async (req, res) => {
  try {
    const solicitanteId = req.user?.id || req.body.id_usuario;
    if (!solicitanteId) return badRequest(res, "No se pudo identificar al usuario solicitante");

    const solicitanteNombre = await resolveUserName(req, solicitanteId);

    const userRepo = new UserRepository();
    const useCase  = new ConfirmarEtapaProduccion(prodRepo, userRepo);
    const result   = await useCase.execute(req.params.id, solicitanteId, solicitanteNombre);
    return ok(res, result);
  } catch (err) {
    if (err.statusCode === 404) return notFound(res, err.message);
    if (err.statusCode === 422 || err.statusCode === 403 || err.statusCode === 401) return badRequest(res, err.message);
    return handleError(res, err);
  }
};

// ── PUT /produccion/detalle-orden/:id ────────────────────────────────────────
// Actualiza un detalle de orden (cantidad, color, etc.)
const updateOrderDetail = async (req, res) => {
  try {
    const detail = await detailRepo.findById(req.params.id);
    if (!detail) return notFound(res, "Detalle no encontrado");

    const order = await prodRepo.findById(detail.id_orden);
    const productionIndex = Production.ESTADOS_VALIDOS.indexOf("Producción");
    const isDamageAdjustment = req.body?.ajusteDanio === true;
    if (!isDamageAdjustment && order && Production.ESTADOS_VALIDOS.indexOf(order.estado) >= productionIndex) {
      return badRequest(res, "No se pueden editar detalles cuando la orden está en Producción o una etapa posterior");
    }

    const ALLOWED_FIELDS = new Set(["cantidad", "color", "id_producto", "refCorte"]);
    const changes = {};
    for (const [key, value] of Object.entries(req.body)) {
      if (ALLOWED_FIELDS.has(key) && value !== undefined) {
        changes[key] = key === "cantidad" ? Number(value) : value;
      }
    }

    if (Object.prototype.hasOwnProperty.call(changes, "cantidad") && (!changes.cantidad || changes.cantidad < 0)) {
      return badRequest(res, "La cantidad debe ser un número positivo");
    }

    const updated = await detailRepo.update(req.params.id, changes);
    if (!updated) return serverError(res, "Error al actualizar el detalle");

    // Registrar en el historial de la orden
    const userId = req.user?.id || req.user?._id || null;
    const userName = await resolveUserName(req, userId);
    await prodRepo.agregarHistorial(
      detail.id_orden,
      `Detalle actualizado: producto ${detail.id_producto} - cambios: ${JSON.stringify(changes)}`,
      userId,
      userName,
      "Actualización",
    ).catch(() => {});

    return ok(res, updated.toJSON ? updated.toJSON() : updated);
  } catch (err) {
    return handleError(res, err);
  }
};

// ── DELETE /produccion/asignaciones/:id ──────────────────────────────────────
// Elimina una asignación de tercero individual
const deleteAssignment = async (req, res) => {
  try {
    const assignment = await assignmentRepo.findById(req.params.id);
    if (!assignment) return notFound(res, "Asignación no encontrada");

    const deleted = await assignmentRepo.delete(req.params.id);
    if (!deleted) return serverError(res, "Error al eliminar la asignación");

    return ok(res, { deleted: true });
  } catch (err) {
    return handleError(res, err);
  }
};

// ── DELETE /produccion/asignaciones/orden/:id_orden ──────────────────────────
// Elimina todas las asignaciones de terceros para una orden
const deleteAssignmentsByOrder = async (req, res) => {
  try {
    const deletedCount = await assignmentRepo.deleteByOrder(req.params.id_orden);
    return ok(res, { deleted: deletedCount });
  } catch (err) {
    return handleError(res, err);
  }
};

const agregarHistorial = async (req, res) => {
  try {
    const { motivo, estado } = req.body;
    const userId = req.body.id_usuario || req.user?.id || null;
    const user = await resolveUserName(req, userId);
    const order = await prodRepo.findById(req.params.id);
    if (!order) return notFound(res, "Orden no encontrada");
    const estadoRegistro = estado || order.estado;
    const updated = await prodRepo.agregarHistorial(req.params.id, motivo, userId, user, estadoRegistro);
    return ok(res, updated ? updated.toJSON() : order.toJSON());
  } catch (err) {
    return handleError(res, err);
  }
};

module.exports = {
  getOrders,
  getOrderById,
  createOrder,
  updateOrder,
  anularOrder,
  cambiarEstado,
  asignarEmpleado,
  reasignarEmpleado,
  confirmarEtapa,
  getEstados,
  getOrderDetails,
  createOrderDetail,
  updateOrderDetail,
  deleteOrderDetail,
  getAssignments,
  createAssignment,
  deleteAssignment,
  deleteAssignmentsByOrder,
  getEmployeeWorkload,
  getCalendario,
  getAlertas,
  agregarHistorial,
};

